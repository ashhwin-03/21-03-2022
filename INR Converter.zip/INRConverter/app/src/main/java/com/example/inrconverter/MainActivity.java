package com.example.inrconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    EditText money_ET;
    Button convert_btn;
    Spinner spinner;
    TextView rupees;

    ArrayAdapter adapter;

    String list,getMoney;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        money_ET = findViewById(R.id.value_ET);
        convert_btn = findViewById(R.id.convert_btn);
        rupees = findViewById(R.id.rupees);
        spinner = findViewById(R.id.spinner);

        adapter = ArrayAdapter.createFromResource(this,R.array.currencies, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                list = parent.getItemAtPosition(position).toString();
                switch(list){
                    case "KWD - Kuwaiti Dinar":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 250.15));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "BHD - Bahraini Dinar":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 201.58));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "OMR - Omani Riyal":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 197.37));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "JOD - Jordanian Dinar":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 107.00));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "GBP - Pound":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 100.11));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "EUR - Euro":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 84.08 ));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "USD - US Dollar":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 75.95));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "TRY - Turkish Lira":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 5.13));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "QAR - Qatari Rial":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 20.86));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "CAD - Canadian Dollar":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 60.25));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "AUD - Australian Dollar":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 56.39));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "SGD - Singapore Dollar": {
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if (getMoney.isEmpty()) {
                                    Toast.makeText(getApplicationContext(), "Please enter some $$$ to convert", Toast.LENGTH_SHORT).show();
                                } else {
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 56.00));
                                    rupees.setText("₹ " + store);
                                }
                            }
                        });
                        break;
                    }
                    case "SAR - Saudi Riyal":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 20.24));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                    case "NPR - Nepalese Rupee":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney = money_ET.getText().toString();
                                if(getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"Please enter some $$$ to convert",Toast.LENGTH_SHORT).show();
                                }else{
                                    double converToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(converToDouble_et * 0.62));
                                    rupees.setText("₹ "+store);
                                }
                            }
                        });
                        break;
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
}